# GRANTH AI — GitHub से Debug APK बनाने के चरण

## इस पैकेज में
- `android/` — Android ऐप का Kotlin स्रोत और Gradle configuration
- `backend/` — Python OCR/API backend और automated tests
- `.github/workflows/android-apk.yml` — GitHub Actions build workflow
- `README_HI.md` — परियोजना व चलाने की जानकारी

## GitHub पर APK बनाना
1. GitHub में नया repository बनाएँ, उदाहरण: `GRANTH-AI`.
2. इस ZIP को extract करें। Extract हुई directory के अंदर की सभी files/folders (विशेषकर छिपा हुआ `.github/`) repository root में upload करें।
3. GitHub repository में **Actions** tab खोलें और workflow enable करें, यदि पूछा जाए।
4. **GRANTH AI Android APK and Backend Tests** workflow खोलें और **Run workflow** दबाएँ। `main`/`master` पर push करने से भी workflow चलेगा।
5. सफल workflow run खोलें। नीचे **Artifacts** में `GRANTH-AI-debug-apk` डाउनलोड करें।
6. ZIP खोलें; उसमें `app-debug.apk` होगा।

## महत्त्वपूर्ण
- यह workflow Debug APK बनाता है, Play Store release-signed APK नहीं।
- इस पैकेज को अभी इस वातावरण में Android SDK/Gradle न होने के कारण compile करके प्रमाणित नहीं किया गया है। GitHub Actions का हरा build ही APK बनने का प्रमाण होगा।
- `.env` या कोई वास्तविक API secret GitHub पर upload/commit न करें। `.env.example` केवल नमूना है।
- Remote backend के लिए HTTPS और निजी API key आवश्यक हैं।
