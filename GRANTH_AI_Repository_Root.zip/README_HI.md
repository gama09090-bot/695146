# GRANTH AI — पुस्तक डिजिटलीकरण ऐप (Rebuild 1.0)

यह अपलोड किए गए Beta 1.3 दस्तावेज़ों पर आधारित नया, स्वच्छ स्रोत-कोड पुनर्निर्माण है। मूल Kotlin/Python स्रोत ZIP उपलब्ध नहीं था; इसलिए इसे पुराने कोड का line-by-line patch नहीं, बल्कि उपलब्ध specification के अनुसार पुनर्निर्मित प्रोजेक्ट समझें।

## अभी उपलब्ध सुविधाएँ

| भाग | स्थिति |
|---|---|
| Android फ़ाइल चयन | PDF, JPG, PNG, WEBP, TIFF और multiple files |
| PDF handling | `PdfRenderer` से पृष्ठवार bitmap, सीमित raster आकार |
| स्थानीय OCR | ML Kit Devanagari + Latin recognizers |
| पृष्ठ संपादन | पृष्ठवार text editor, अगला/पिछला पृष्ठ |
| स्थानीय draft | SharedPreferences में स्वतः सहेजना |
| स्थानीय निर्यात | UTF-8 TXT, basic OOXML DOCX, EPUB 3 |
| Backend OCR | multipart batch endpoint, JSON text review |
| Searchable PDF | server पर scanned background + invisible OCR text layer |
| API सुरक्षा | optional Bearer key; Android Keystore AES-GCM; HTTPS policy |
| Backend | FastAPI, Tesseract, PDF/image/TIFF, DOCX/EPUB endpoints |
| CI | Backend pytest और GitHub Actions Debug APK build workflow |

## Android build

आवश्यक: JDK 17, Android SDK Platform 36, Android Build Tools 36.0.0, Gradle 8.13.

```bash
cd android
gradle wrapper --gradle-version 8.13 --distribution-type bin
./gradlew testDebugUnitTest assembleDebug
```

APK path:

`android/app/build/outputs/apk/debug/app-debug.apk`

यह Debug APK होगा, Play Store / production signed APK नहीं। इस वातावरण में Android SDK/Gradle उपलब्ध नहीं थे, इसलिए यहाँ APK compile या install करके सत्यापित नहीं किया गया है। GitHub Actions workflow सफल होने पर artifact उपलब्ध होगा।

## Backend चलाना

आवश्यक: Python 3.12+, Tesseract OCR और `hin`, `eng` traineddata.

```bash
cd backend
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements-dev.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

API दस्तावेज़: `http://127.0.0.1:8000/docs`  
Health: `http://127.0.0.1:8000/health`

### Docker Compose

Project root से:

```bash
cp .env.example .env
# .env में अपना लंबा निजी GRANTH_API_KEY रखें
docker compose -f compose.backend.yml up --build
```

Compose केवल `127.0.0.1:8000` पर bind करता है। Remote/LAN उपयोग के लिए TLS reverse proxy, firewall और HTTPS आवश्यक हैं। API key को HTTP पर कभी न भेजें।

## Android में Backend जोड़ना

- `https://...` remote/LAN Backend के लिए मान्य है।
- `http://localhost` और `http://127.0.0.1` केवल उसी device के स्थानीय विकास के लिए हैं।
- `http://10.0.2.2` केवल Android Emulator development के लिए है और इस पर API key नहीं भेजी जाती।
- Android API 23 पर HTTP बंद है; HTTPS उपयोग करें।

## महत्वपूर्ण तकनीकी सीमाएँ

1. ML Kit स्थानीय OCR confidence score उपलब्ध नहीं कराता; इस UI में local confidence का दावा नहीं किया गया है।
2. Android में सीधे camera capture UI अभी शामिल नहीं; कैमरे से ली गई फ़ोटो को फ़ाइल picker से चुना जा सकता है।
3. Android DOCX/EPUB export text-first है; यह पूर्ण typography, original print layout या OCR table reconstruction नहीं करता। Backend DOCX/EPUB में table matrix समर्थन है।
4. Searchable PDF में scan image और invisible OCR text layer रहती है; यह fully editable document नहीं है।
5. OCR परिणामों में वर्तनी/गणितीय सूत्र/तालिकाओं की त्रुटियाँ हो सकती हैं। मूल पुस्तक से proofreading आवश्यक है।
6. Backend OCR और Searchable PDF स्रोत फ़ाइलें चुने हुए server पर upload करते हैं। संवेदनशील पुस्तकें केवल विश्वसनीय HTTPS server पर भेजें।
7. Backend इस starter में user accounts, multi-tenant isolation, permanent file store, audit log, advanced rate limiting या abuse monitoring नहीं देता। सार्वजनिक इंटरनेट पर सीधे expose न करें।
8. केवल उन्हीं पुस्तकों को डिजिटाइज़ करें जिनके लिए आपके पास अधिकार/अनुमति हो।

## परीक्षण

Backend परीक्षण:

```bash
cd backend
pytest
```

Android unit test और APK build GitHub Actions में चलेंगे। Workflow run की सफलता के बिना Android APK को compiled/verified न मानें।
