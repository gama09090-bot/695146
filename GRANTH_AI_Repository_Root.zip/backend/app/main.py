from __future__ import annotations

import io
import os
import re
import secrets
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import fitz
import pytesseract
from docx import Document
from docx.enum.text import WD_BREAK
from docx.shared import Inches, Pt
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import Response
from PIL import Image, ImageOps, UnidentifiedImageError
from pydantic import BaseModel, Field

APP_NAME = "GRANTH AI"
MAX_UPLOAD_BYTES = 100 * 1024 * 1024
MAX_BATCH_PAGES = 200
MAX_RASTER_PIXELS = 50_000_000
MAX_RASTER_AXIS = 12_000
ALLOWED_LANGS = re.compile(r"^[a-z]{3}(\+[a-z]{3}){0,4}$")
ALLOWED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff"}

app = FastAPI(title="GRANTH AI API", version="1.0.0", description="Hindi/English book digitisation API")


class ExportPage(BaseModel):
    page_number: int = Field(ge=1)
    text: str = ""
    tables: list[list[list[str]]] = Field(default_factory=list)


class ExportRequest(BaseModel):
    title: str = "मेरी डिजिटल पुस्तक"
    pages: list[ExportPage] = Field(min_length=1, max_length=200)


def auth_guard(authorization: str | None = Header(default=None)) -> None:
    expected = os.getenv("GRANTH_API_KEY", "").strip()
    if not expected:
        return
    scheme, _, supplied = (authorization or "").partition(" ")
    if scheme.lower() != "bearer" or not supplied or not secrets.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail="मान्य Bearer API key आवश्यक है।")


def validate_language(language: str) -> str:
    value = language.strip().lower()
    if not ALLOWED_LANGS.fullmatch(value):
        raise HTTPException(status_code=422, detail="language में मान्य Tesseract codes दें, जैसे hin+eng।")
    return value


def read_upload(upload: UploadFile) -> bytes:
    suffix = Path(upload.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=415, detail=f"असमर्थित फ़ाइल प्रकार: {suffix or 'unknown'}")
    data = upload.file.read(MAX_UPLOAD_BYTES + 1)
    if not data:
        raise HTTPException(status_code=422, detail="खाली फ़ाइल स्वीकार नहीं है।")
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="एक फ़ाइल की सीमा 100 MB है।")
    return data


def check_dimensions(width: int, height: int) -> None:
    if width <= 0 or height <= 0 or width > MAX_RASTER_AXIS or height > MAX_RASTER_AXIS or width * height > MAX_RASTER_PIXELS:
        raise HTTPException(status_code=413, detail="पृष्ठ/चित्र का आकार सुरक्षा सीमा से बड़ा है।")


def pdf_page_images(data: bytes, dpi: int) -> list[Image.Image]:
    try:
        doc = fitz.open(stream=data, filetype="pdf")
    except Exception as exc:
        raise HTTPException(status_code=422, detail="PDF पढ़ा नहीं जा सका।") from exc
    images: list[Image.Image] = []
    try:
        if doc.page_count > MAX_BATCH_PAGES:
            raise HTTPException(status_code=413, detail="एक PDF में अधिकतम 200 पृष्ठ अनुमत हैं।")
        scale = dpi / 72.0
        for page in doc:
            rect = page.rect
            width, height = int(rect.width * scale), int(rect.height * scale)
            check_dimensions(width, height)
            pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
            images.append(Image.frombytes("RGB", [pix.width, pix.height], pix.samples))
    finally:
        doc.close()
    return images


def image_frames(data: bytes) -> list[Image.Image]:
    try:
        with Image.open(io.BytesIO(data)) as img:
            frames: list[Image.Image] = []
            frame_count = getattr(img, "n_frames", 1)
            if frame_count > MAX_BATCH_PAGES:
                raise HTTPException(status_code=413, detail="बहुपृष्ठीय TIFF में अधिकतम 200 फ्रेम अनुमत हैं।")
            for index in range(frame_count):
                img.seek(index)
                check_dimensions(*img.size)
                frame = ImageOps.exif_transpose(img.copy()).convert("RGB")
                frames.append(frame)
            return frames
    except (UnidentifiedImageError, OSError) as exc:
        raise HTTPException(status_code=422, detail="चित्र पढ़ा नहीं जा सका।") from exc


def decode_document(data: bytes, filename: str, dpi: int) -> list[Image.Image]:
    suffix = Path(filename or "").suffix.lower()
    if suffix == ".pdf":
        return pdf_page_images(data, dpi)
    if suffix in ALLOWED_EXTENSIONS:
        return image_frames(data)
    raise HTTPException(status_code=415, detail="असमर्थित फ़ाइल प्रकार।")



def preflight_document(data: bytes, filename: str, dpi: int) -> int:
    """Validate page counts and source dimensions before starting OCR work."""
    suffix = Path(filename or "").suffix.lower()
    if suffix == ".pdf":
        try:
            doc = fitz.open(stream=data, filetype="pdf")
        except Exception as exc:
            raise HTTPException(status_code=422, detail="PDF पढ़ा नहीं जा सका।") from exc
        try:
            if doc.page_count > MAX_BATCH_PAGES:
                raise HTTPException(status_code=413, detail="एक PDF में अधिकतम 200 पृष्ठ अनुमत हैं।")
            scale = dpi / 72.0
            for page in doc:
                rect = page.rect
                check_dimensions(int(rect.width * scale), int(rect.height * scale))
            return doc.page_count
        finally:
            doc.close()
    if suffix in ALLOWED_EXTENSIONS:
        try:
            with Image.open(io.BytesIO(data)) as img:
                count = getattr(img, "n_frames", 1)
                if count > MAX_BATCH_PAGES:
                    raise HTTPException(status_code=413, detail="बहुपृष्ठीय TIFF में अधिकतम 200 फ्रेम अनुमत हैं।")
                for index in range(count):
                    img.seek(index)
                    check_dimensions(*img.size)
                return count
        except (UnidentifiedImageError, OSError) as exc:
            raise HTTPException(status_code=422, detail="चित्र पढ़ा नहीं जा सका।") from exc
    raise HTTPException(status_code=415, detail="असमर्थित फ़ाइल प्रकार।")

def layout_hint(words: list[dict[str, Any]], image_width: int) -> str:
    if not words:
        return "एक-स्तंभ"
    left = [w for w in words if w["x"] < image_width * 0.48]
    right = [w for w in words if w["x"] > image_width * 0.52]
    left_ys = [w["y"] for w in left]
    right_ys = [w["y"] for w in right]
    overlap = bool(left_ys and right_ys and max(min(left_ys), min(right_ys)) < min(max(left_ys), max(right_ys)))
    return "दो-स्तंभ (अनुमान)" if overlap and len(left) >= 8 and len(right) >= 8 else "एक-स्तंभ"


def detect_ruled_table_candidates(image: Image.Image) -> list[dict[str, Any]]:
    """Conservative line-projection heuristic; returns candidate regions only."""
    gray = ImageOps.grayscale(image)
    width, height = gray.size
    # Downsample first so the detector has bounded memory and runtime.
    scale = min(1.0, 1600 / max(width, height))
    if scale < 1:
        gray = gray.resize((max(1, int(width * scale)), max(1, int(height * scale))))
    px = gray.load(); w, h = gray.size
    row_hits = [sum(1 for x in range(w) if px[x, y] < 90) / w for y in range(h)]
    col_hits = [sum(1 for y in range(h) if px[x, y] < 90) / h for x in range(w)]
    horizontal = sum(v > 0.75 for v in row_hits)
    vertical = sum(v > 0.75 for v in col_hits)
    if horizontal >= 3 and vertical >= 2:
        return [{"kind": "ruled-grid-candidate", "confidence": 0.35, "note": "रेखाओं पर आधारित अनुमान; सत्यापन आवश्यक है।"}]
    return []


def ocr_page(image: Image.Image, language: str, page_number: int) -> dict[str, Any]:
    try:
        data = pytesseract.image_to_data(image, lang=language, output_type=pytesseract.Output.DICT)
    except pytesseract.TesseractNotFoundError as exc:
        raise HTTPException(status_code=503, detail="सर्वर पर Tesseract उपलब्ध नहीं है।") from exc
    except pytesseract.TesseractError as exc:
        raise HTTPException(status_code=422, detail=f"OCR भाषा/प्रक्रिया त्रुटि: {exc}") from exc
    words: list[dict[str, Any]] = []
    tokens: list[str] = []
    confidences: list[float] = []
    for i, raw in enumerate(data.get("text", [])):
        token = str(raw).strip()
        try:
            confidence = float(data["conf"][i])
        except (ValueError, TypeError, KeyError):
            confidence = -1
        if not token or confidence < 0:
            continue
        x, y = int(data["left"][i]), int(data["top"][i])
        w, h = int(data["width"][i]), int(data["height"][i])
        item = {"text": token, "confidence": round(confidence, 2), "x": x, "y": y, "width": w, "height": h}
        words.append(item); tokens.append(token); confidences.append(confidence)
    # Build lines in native Tesseract order, preserving paragraph flow.
    lines: dict[tuple[int, int, int], list[str]] = {}
    for i, token in enumerate(data.get("text", [])):
        token = str(token).strip()
        try:
            conf = float(data["conf"][i])
        except (ValueError, TypeError, KeyError):
            conf = -1
        if token and conf >= 0:
            key = (int(data["block_num"][i]), int(data["par_num"][i]), int(data["line_num"][i]))
            lines.setdefault(key, []).append(token)
    text = "\n".join(" ".join(parts) for parts in lines.values())
    avg = round(sum(confidences) / len(confidences), 2) if confidences else 0.0
    low = [word for word in words if word["confidence"] < 60]
    return {
        "page_number": page_number,
        "text": text,
        "word_count": len(words),
        "average_confidence": avg,
        "low_confidence_words": low,
        "words": words,
        "layout": layout_hint(words, image.width),
        "tables": detect_ruled_table_candidates(image),
        "warnings": (["OCR confidence कम है; मूल पृष्ठ से मिलान करें।"] if low else []),
        "image_size": {"width": image.width, "height": image.height},
    }


def process_file(data: bytes, filename: str, language: str, dpi: int, start_page: int = 1) -> list[dict[str, Any]]:
    images = decode_document(data, filename, dpi)
    return [ocr_page(image, language, start_page + idx) for idx, image in enumerate(images)]


def build_searchable_pdf(data: bytes, filename: str, language: str, dpi: int) -> bytes:
    images = decode_document(data, filename, dpi)
    result = fitz.open()
    try:
        for image in images:
            page = result.new_page(width=image.width * 72 / dpi, height=image.height * 72 / dpi)
            img_stream = io.BytesIO(); image.save(img_stream, format="PNG")
            page.insert_image(page.rect, stream=img_stream.getvalue())
            ocr = pytesseract.image_to_data(image, lang=language, output_type=pytesseract.Output.DICT)
            sx = page.rect.width / image.width; sy = page.rect.height / image.height
            devanagari_font = "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Regular.ttf"
            font_name = "helv"
            if Path(devanagari_font).exists():
                page.insert_font(fontname="GranthNoto", fontfile=devanagari_font)
                font_name = "GranthNoto"
            for i, raw in enumerate(ocr.get("text", [])):
                token = str(raw).strip()
                try: confidence = float(ocr["conf"][i])
                except (ValueError, TypeError, KeyError): confidence = -1
                if not token or confidence < 0: continue
                x, y = int(ocr["left"][i]), int(ocr["top"][i])
                h = int(ocr["height"][i])
                # A baseline insertion avoids textbox-fit failures for short OCR words.
                token_font = "helv" if token.isascii() else font_name
                page.insert_text((x*sx, (y+h)*sy), token, fontname=token_font,
                                 fontsize=max(4, min(14, h*sy*0.82)), render_mode=3, overlay=True)
        return result.tobytes(deflate=True, garbage=4)
    finally:
        result.close()


def normalised_title(title: str) -> str:
    clean = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", "_", title).strip()[:100]
    return clean or "मेरी डिजिटल पुस्तक"


def export_docx(payload: ExportRequest) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.7); section.bottom_margin = Inches(0.7)
    title = normalised_title(payload.title)
    doc.add_heading(title, 0)
    for index, page in enumerate(payload.pages):
        if index:
            doc.add_page_break()
        doc.add_heading(f"पृष्ठ {page.page_number}", level=2)
        for line in page.text.splitlines():
            doc.add_paragraph(line)
        for table_data in page.tables:
            rows = [row for row in table_data if isinstance(row, list)]
            if not rows: continue
            cols = max((len(row) for row in rows), default=0)
            if not cols: continue
            table = doc.add_table(rows=0, cols=cols)
            table.style = "Table Grid"
            for row in rows:
                cells = table.add_row().cells
                for col, value in enumerate(row[:cols]):
                    cells[col].text = str(value)
    stream = io.BytesIO(); doc.save(stream); return stream.getvalue()


def export_epub(payload: ExportRequest) -> bytes:
    title = normalised_title(payload.title)
    stamp = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    def esc(value: Any) -> str:
        return (str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;"))
    manifest_items = []; spine_items = []; chapters = []
    for i, page in enumerate(payload.pages, 1):
        name = f"page{i:04d}.xhtml"
        body = "".join(f"<p>{esc(line)}</p>" for line in page.text.splitlines())
        for table_data in page.tables:
            body += "<table><tbody>"
            for row in table_data:
                body += "<tr>" + "".join(f"<td>{esc(cell)}</td>" for cell in row) + "</tr>"
            body += "</tbody></table>"
        chapters.append((name, f'''<?xml version="1.0" encoding="utf-8"?>\n<html xmlns="http://www.w3.org/1999/xhtml" lang="hi"><head><title>पृष्ठ {page.page_number}</title><meta charset="utf-8"/></head><body><h1>पृष्ठ {page.page_number}</h1>{body}</body></html>'''))
        manifest_items.append(f'<item id="p{i}" href="{name}" media-type="application/xhtml+xml"/>')
        spine_items.append(f'<itemref idref="p{i}"/>')
    opf = f'''<?xml version="1.0" encoding="utf-8"?>\n<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid" xml:lang="hi"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="bookid">urn:uuid:{secrets.token_hex(16)}</dc:identifier><dc:title>{esc(title)}</dc:title><dc:language>hi</dc:language><meta property="dcterms:modified">{stamp}</meta></metadata><manifest>{''.join(manifest_items)}</manifest><spine>{''.join(spine_items)}</spine></package>'''
    container = '''<?xml version="1.0" encoding="UTF-8"?>\n<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>'''
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w") as archive:
        archive.writestr("mimetype", "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        archive.writestr("META-INF/container.xml", container)
        archive.writestr("OEBPS/content.opf", opf)
        for name, content in chapters: archive.writestr(f"OEBPS/{name}", content)
    return stream.getvalue()


@app.get("/health")
def health() -> dict[str, Any]:
    try:
        languages = sorted(pytesseract.get_languages(config=""))
        tesseract_ok = True
    except Exception:
        languages = []; tesseract_ok = False
    return {"service": APP_NAME, "version": app.version, "tesseract_available": tesseract_ok,
            "languages": languages, "api_key_required": bool(os.getenv("GRANTH_API_KEY", "").strip())}


@app.post("/api/v1/ocr/file", dependencies=[Depends(auth_guard)])
def ocr_file(file: UploadFile = File(...), language: str = Form("hin+eng"), dpi: int = Form(220)) -> dict[str, Any]:
    if not 100 <= dpi <= 350: raise HTTPException(status_code=422, detail="dpi की सीमा 100–350 है।")
    data = read_upload(file); lang = validate_language(language)
    pages = process_file(data, file.filename or "upload.bin", lang, dpi)
    return {"filename": file.filename, "page_count": len(pages), "pages": pages}


@app.post("/api/v1/ocr/batch", dependencies=[Depends(auth_guard)])
def ocr_batch(files: list[UploadFile] = File(...), language: str = Form("hin+eng"), dpi: int = Form(220)) -> dict[str, Any]:
    if not files: raise HTTPException(status_code=422, detail="कम से कम एक फ़ाइल चुनें।")
    if not 100 <= dpi <= 350: raise HTTPException(status_code=422, detail="dpi की सीमा 100–350 है।")
    lang = validate_language(language); aggregate = 0; planned_pages = 0; prepared = []
    # Read and preflight every file first so an over-limit batch is rejected before OCR starts.
    for upload in files:
        data = read_upload(upload); aggregate += len(data)
        if aggregate > MAX_UPLOAD_BYTES: raise HTTPException(status_code=413, detail="बैच अपलोड की कुल सीमा 100 MB है।")
        count = preflight_document(data, upload.filename or "upload.bin", dpi)
        planned_pages += count
        if planned_pages > MAX_BATCH_PAGES: raise HTTPException(status_code=413, detail="बैच में अधिकतम 200 OCR पृष्ठ अनुमत हैं।")
        prepared.append((upload.filename or "upload.bin", data, count))
    all_pages = []; file_results = []; next_page = 1
    for filename, data, _count in prepared:
        pages = process_file(data, filename, lang, dpi, next_page)
        all_pages.extend(pages); file_results.append({"filename": filename, "page_count": len(pages)})
        next_page += len(pages)
    return {"file_count": len(files), "page_count": len(all_pages), "files": file_results, "pages": all_pages}


@app.post("/api/v1/ocr/searchable-pdf", dependencies=[Depends(auth_guard)])
def searchable_pdf(file: UploadFile = File(...), language: str = Form("hin+eng"), dpi: int = Form(220)) -> Response:
    if not 100 <= dpi <= 350: raise HTTPException(status_code=422, detail="dpi की सीमा 100–350 है।")
    data = read_upload(file); result = build_searchable_pdf(data, file.filename or "upload.bin", validate_language(language), dpi)
    return Response(result, media_type="application/pdf", headers={"Content-Disposition": 'attachment; filename="granth-searchable.pdf"'})


@app.post("/api/v1/ocr/searchable-pdf/batch", dependencies=[Depends(auth_guard)])
def searchable_pdf_batch(files: list[UploadFile] = File(...), language: str = Form("hin+eng"), dpi: int = Form(220)) -> Response:
    if not files: raise HTTPException(status_code=422, detail="कम से कम एक फ़ाइल चुनें।")
    if not 100 <= dpi <= 350: raise HTTPException(status_code=422, detail="dpi की सीमा 100–350 है।")
    lang = validate_language(language); aggregate = 0; planned_pages = 0; prepared = []
    for upload in files:
        data = read_upload(upload); aggregate += len(data)
        if aggregate > MAX_UPLOAD_BYTES: raise HTTPException(status_code=413, detail="बैच अपलोड की कुल सीमा 100 MB है।")
        count = preflight_document(data, upload.filename or "upload.bin", dpi)
        planned_pages += count
        if planned_pages > MAX_BATCH_PAGES: raise HTTPException(status_code=413, detail="बैच में अधिकतम 200 OCR पृष्ठ अनुमत हैं।")
        prepared.append((upload.filename or "upload.bin", data))
    merged = fitz.open()
    try:
        for filename, data in prepared:
            pdf_bytes = build_searchable_pdf(data, filename, lang, dpi)
            part = fitz.open(stream=pdf_bytes, filetype="pdf")
            merged.insert_pdf(part); part.close()
        output = merged.tobytes(deflate=True, garbage=4)
    finally: merged.close()
    return Response(output, media_type="application/pdf", headers={"Content-Disposition": 'attachment; filename="granth-searchable-batch.pdf"', "X-GRANTH-Page-Count": str(planned_pages)})


@app.post("/api/v1/export/docx", dependencies=[Depends(auth_guard)])
def docx_export(payload: ExportRequest) -> Response:
    return Response(export_docx(payload), media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    headers={"Content-Disposition": 'attachment; filename="granth-book.docx"'})


@app.post("/api/v1/export/epub", dependencies=[Depends(auth_guard)])
def epub_export(payload: ExportRequest) -> Response:
    return Response(export_epub(payload), media_type="application/epub+zip",
                    headers={"Content-Disposition": 'attachment; filename="granth-book.epub"'})
