import io
import os
import zipfile

import fitz
import pytest
from docx import Document
from fastapi.testclient import TestClient
from PIL import Image

from app import main


@pytest.fixture
def client():
    return TestClient(main.app)


def make_png():
    buf = io.BytesIO()
    Image.new("RGB", (40, 30), "white").save(buf, format="PNG")
    return buf.getvalue()


def test_health_does_not_reveal_secret(client, monkeypatch):
    monkeypatch.setenv("GRANTH_API_KEY", "top-secret-example")
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["api_key_required"] is True
    assert "top-secret-example" not in res.text


def test_processing_routes_require_bearer_key(client, monkeypatch):
    monkeypatch.setenv("GRANTH_API_KEY", "right-key")
    denied = client.post("/api/v1/export/docx", json={"title": "किताब", "pages": [{"page_number": 1, "text": "भारत"}]})
    assert denied.status_code == 401
    allowed = client.post("/api/v1/export/docx", headers={"Authorization": "Bearer right-key"},
                          json={"title": "किताब", "pages": [{"page_number": 1, "text": "भारत"}]})
    assert allowed.status_code == 200
    assert allowed.headers["content-type"].startswith("application/vnd.openxmlformats")


def test_invalid_bearer_is_rejected(client, monkeypatch):
    monkeypatch.setenv("GRANTH_API_KEY", "right-key")
    res = client.post("/api/v1/export/epub", headers={"Authorization": "Bearer wrong"},
                      json={"title": "किताब", "pages": [{"page_number": 1, "text": "पाठ"}]})
    assert res.status_code == 401


def test_docx_exports_unicode_and_editable_table(client, monkeypatch):
    monkeypatch.delenv("GRANTH_API_KEY", raising=False)
    payload = {"title": "राजस्थान इतिहास", "pages": [{"page_number": 1, "text": "भारत\nराजस्थान",
               "tables": [[ ["क्रम", "नाम"], ["1", "मेवाड़"] ]]}]}
    res = client.post("/api/v1/export/docx", json=payload)
    assert res.status_code == 200
    doc = Document(io.BytesIO(res.content))
    assert "राजस्थान" in " ".join(p.text for p in doc.paragraphs)
    assert len(doc.tables) == 1
    assert doc.tables[0].cell(1, 1).text == "मेवाड़"


def test_epub_has_mimetype_metadata_and_unicode_pages(client, monkeypatch):
    monkeypatch.delenv("GRANTH_API_KEY", raising=False)
    res = client.post("/api/v1/export/epub", json={"title": "मेरी पुस्तक", "pages": [
        {"page_number": 1, "text": "हिंदी और English"}]})
    assert res.status_code == 200
    with zipfile.ZipFile(io.BytesIO(res.content)) as zf:
        assert zf.namelist()[0] == "mimetype"
        assert zf.read("mimetype") == b"application/epub+zip"
        opf = zf.read("OEBPS/content.opf").decode()
        xhtml = zf.read("OEBPS/page0001.xhtml").decode()
        assert "dcterms:modified" in opf
        assert "हिंदी" in xhtml


def test_language_and_dpi_validation(client, monkeypatch):
    monkeypatch.delenv("GRANTH_API_KEY", raising=False)
    res = client.post("/api/v1/ocr/file", data={"language": "../../bad", "dpi": "220"},
                      files={"file": ("page.png", make_png(), "image/png")})
    assert res.status_code == 422
    res = client.post("/api/v1/ocr/file", data={"language": "hin+eng", "dpi": "80"},
                      files={"file": ("page.png", make_png(), "image/png")})
    assert res.status_code == 422


def test_unsupported_extension_rejected(client, monkeypatch):
    monkeypatch.delenv("GRANTH_API_KEY", raising=False)
    res = client.post("/api/v1/ocr/file", data={"language": "hin+eng", "dpi": "220"},
                      files={"file": ("page.exe", b"abc", "application/octet-stream")})
    assert res.status_code == 415


def test_oversized_dimensions_rejected():
    with pytest.raises(Exception):
        main.check_dimensions(12001, 10)
    with pytest.raises(Exception):
        main.check_dimensions(8000, 8000)


def test_pdf_page_raster_dimensions_are_checked_before_render():
    doc = fitz.open()
    doc.new_page(width=9000, height=100)
    raw = doc.tobytes(); doc.close()
    with pytest.raises(Exception):
        main.pdf_page_images(raw, 220)


def test_multi_frame_tiff_is_expanded():
    frames = [Image.new("RGB", (20, 20), "white"), Image.new("RGB", (20, 20), "black")]
    buf = io.BytesIO(); frames[0].save(buf, format="TIFF", save_all=True, append_images=frames[1:])
    decoded = main.image_frames(buf.getvalue())
    assert len(decoded) == 2


def test_ocr_endpoint_returns_page_structures(client, monkeypatch):
    monkeypatch.delenv("GRANTH_API_KEY", raising=False)
    monkeypatch.setattr(main, "process_file", lambda *a, **k: [{"page_number": 1, "text": "नमस्ते", "words": [], "tables": []}])
    res = client.post("/api/v1/ocr/file", data={"language": "hin+eng", "dpi": "220"},
                      files={"file": ("page.png", make_png(), "image/png")})
    assert res.status_code == 200
    assert res.json()["pages"][0]["text"] == "नमस्ते"


def test_batch_preserves_input_file_order(client, monkeypatch):
    monkeypatch.delenv("GRANTH_API_KEY", raising=False)
    def fake(data, filename, lang, dpi, start_page=1):
        return [{"page_number": start_page, "text": filename}]
    monkeypatch.setattr(main, "process_file", fake)
    res = client.post("/api/v1/ocr/batch", data={"language": "hin+eng", "dpi": "220"}, files=[
        ("files", ("first.png", make_png(), "image/png")),
        ("files", ("second.png", make_png(), "image/png"))])
    assert res.status_code == 200
    assert [p["text"] for p in res.json()["pages"]] == ["first.png", "second.png"]
    assert [p["page_number"] for p in res.json()["pages"]] == [1, 2]


def test_read_upload_enforces_100mb_limit():
    class FakeUpload:
        filename = "test.png"
        def __init__(self): self.file = io.BytesIO(b"x" * (main.MAX_UPLOAD_BYTES + 1))
    with pytest.raises(Exception):
        main.read_upload(FakeUpload())
