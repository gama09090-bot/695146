plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "in.granthai.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "in.granthai.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0-rebuild"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    testOptions { unitTests.isIncludeAndroidResources = false }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-devanagari:16.0.1")
    implementation("com.google.android.gms:play-services-tasks:18.3.0")
    testImplementation("junit:junit:4.13.2")
}
