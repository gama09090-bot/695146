package `in`.granthai.app

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.graphics.pdf.PdfRenderer
import java.io.ByteArrayOutputStream
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object DocumentLoader {
    const val MAX_FILES_BYTES = 100L * 1024L * 1024L
    const val MAX_PAGES = 200
    const val MAX_LONG_SIDE = 2200
    const val MAX_AXIS = 3500
    const val MAX_PIXELS = 5_000_000L

    fun displayName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0) ?: "पृष्ठ"
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "पृष्ठ"
    }

    fun forEachPage(context: Context, uri: Uri, onPage: (Bitmap, Int) -> Unit): Int {
        val resolver = context.contentResolver
        val name = displayName(context, uri)
        val mime = resolver.getType(uri)?.lowercase().orEmpty()
        if (mime == "application/pdf" || name.endsWith(".pdf", true)) {
            val descriptor = resolver.openFileDescriptor(uri, "r") ?: error("PDF नहीं खुला।")
            var processed = 0
            PdfRenderer(descriptor).use { renderer ->
                require(renderer.pageCount <= MAX_PAGES) { "एक PDF में अधिकतम $MAX_PAGES पृष्ठ समर्थित हैं।" }
                for (index in 0 until renderer.pageCount) {
                    renderer.openPage(index).use { page ->
                        val scale = min(1.0, min(MAX_LONG_SIDE.toDouble() / max(page.width, page.height), sqrt(MAX_PIXELS.toDouble() / (page.width.toDouble() * page.height))))
                        val width = max(1, (page.width * scale).toInt())
                        val height = max(1, (page.height * scale).toInt())
                        require(width <= MAX_AXIS && height <= MAX_AXIS && width.toLong() * height <= MAX_PIXELS) { "PDF पृष्ठ का आकार बहुत बड़ा है।" }
                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        try {
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            onPage(bitmap, index + 1)
                        } finally { bitmap.recycle() }
                        processed++
                    }
                }
            }
            return processed
        }
        val bitmap = loadImage(resolver, uri)
        try { onPage(bitmap, 1) } finally { bitmap.recycle() }
        return 1
    }

    private fun loadImage(resolver: ContentResolver, uri: Uri): Bitmap {
        val bytes = resolver.openInputStream(uri)?.use { input ->
            val output = ByteArrayOutputStream(); val buffer = ByteArray(16 * 1024); var total = 0
            while (true) {
                val count = input.read(buffer); if (count < 0) break
                total += count; require(total <= MAX_FILES_BYTES) { "फ़ाइल 100 MB से बड़ी है।" }
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        } ?: error("चित्र नहीं पढ़ा जा सका।")
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "अमान्य चित्र।" }
        require(bounds.outWidth <= 12000 && bounds.outHeight <= 12000 && bounds.outWidth.toLong() * bounds.outHeight <= 50_000_000L) { "चित्र का आकार सुरक्षा सीमा से बड़ा है।" }
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > MAX_LONG_SIDE ||
            (bounds.outWidth / sample).toLong() * (bounds.outHeight / sample) > MAX_PIXELS) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 })
            ?: error("चित्र decode नहीं हुआ।")
        val factor = min(1.0, min(MAX_LONG_SIDE.toDouble() / max(decoded.width, decoded.height), sqrt(MAX_PIXELS.toDouble() / (decoded.width.toDouble() * decoded.height))))
        if (factor >= 0.999) return decoded
        val resized = Bitmap.createScaledBitmap(decoded, max(1, (decoded.width * factor).toInt()), max(1, (decoded.height * factor).toInt()), true)
        if (resized !== decoded) decoded.recycle()
        return resized
    }
}
