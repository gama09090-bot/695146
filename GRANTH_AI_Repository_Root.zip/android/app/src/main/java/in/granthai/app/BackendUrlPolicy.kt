package `in`.granthai.app

import android.os.Build
import java.net.URI

object BackendUrlPolicy {
    private val loopback = setOf("localhost", "127.0.0.1")
    private val developmentHosts = loopback + "10.0.2.2"

    fun validate(raw: String, apiKeyPresent: Boolean, sdk: Int = Build.VERSION.SDK_INT): String? {
        val value = raw.trim().trimEnd('/')
        val uri = try { URI(value) } catch (_: Exception) { return "Backend URL सही नहीं है।" }
        val scheme = uri.scheme?.lowercase() ?: return "URL में https:// या अनुमत स्थानीय http:// दें।"
        val host = uri.host?.lowercase() ?: return "Backend URL में मान्य host नहीं है।"
        if (uri.userInfo != null || uri.query != null || uri.fragment != null) return "URL में user-info, query या fragment न रखें।"
        if (scheme == "https") return null
        if (scheme != "http") return "केवल HTTPS या अनुमत स्थानीय HTTP समर्थित है।"
        if (sdk < 24) return "Android 6/API 23 पर HTTP बंद है; HTTPS उपयोग करें।"
        if (host !in developmentHosts) return "LAN/दूरस्थ Backend के लिए HTTPS आवश्यक है।"
        if (apiKeyPresent && host !in loopback) return "API key के साथ HTTP केवल localhost या 127.0.0.1 पर मान्य है।"
        return null
    }
}
