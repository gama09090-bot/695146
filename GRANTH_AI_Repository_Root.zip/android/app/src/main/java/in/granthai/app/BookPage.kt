package `in`.granthai.app

data class BookPage(
    val sourceName: String,
    var text: String,
    val pageNumber: Int,
    val averageConfidence: Double? = null,
    val lowConfidenceCount: Int = 0,
    val layout: String? = null,
    val warnings: List<String> = emptyList()
)
