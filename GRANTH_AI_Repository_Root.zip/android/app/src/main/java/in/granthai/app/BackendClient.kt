package `in`.granthai.app

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL

class BackendClient(private val context: Context, private val baseUrl: String, private val apiKey: String) {
    private val resolver: ContentResolver = context.contentResolver
    private val boundary = "----GRANTHAI${System.nanoTime()}"

    fun checkHealth(): String {
        val error = BackendUrlPolicy.validate(baseUrl, apiKey.isNotBlank())
        require(error == null) { error ?: "Backend URL अमान्य है।" }
        val connection = (URL(baseUrl.trimEnd('/') + "/health").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 12000; readTimeout = 15000; instanceFollowRedirects = false
        }
        try {
            val code = connection.responseCode
            val text = readLimited(if (code in 200..299) connection.inputStream else connection.errorStream, 8 * 1024)
            check(code in 200..299) { "Backend ने HTTP $code दिया: $text" }
            val json = JSONObject(text)
            return "Backend उपलब्ध: ${json.optString("service", "GRANTH AI")} | API key आवश्यक: ${json.optBoolean("api_key_required")}"
        } finally { connection.disconnect() }
    }

    fun runOcr(uris: List<Uri>): List<BookPage> {
        val response = sendFiles("/api/v1/ocr/batch", uris)
        val json = JSONObject(response.toString(Charsets.UTF_8))
        val array = json.getJSONArray("pages")
        return (0 until array.length()).map { index ->
            val page = array.getJSONObject(index)
            val warningsJson = page.optJSONArray("warnings")
            val warnings = if (warningsJson == null) emptyList() else (0 until warningsJson.length()).map { warningsJson.optString(it) }
            val lowWords = page.optJSONArray("low_confidence_words")
            BookPage(
                sourceName = "Backend OCR",
                text = page.optString("text", ""),
                pageNumber = page.optInt("page_number", index + 1),
                averageConfidence = page.optDouble("average_confidence").takeIf { !it.isNaN() },
                lowConfidenceCount = lowWords?.length() ?: 0,
                layout = page.optString("layout").takeIf { it.isNotBlank() },
                warnings = warnings
            )
        }
    }

    fun searchablePdf(uris: List<Uri>): ByteArray = sendFiles("/api/v1/ocr/searchable-pdf/batch", uris)

    private fun sendFiles(path: String, uris: List<Uri>): ByteArray {
        require(uris.isNotEmpty()) { "कम से कम एक स्रोत फ़ाइल चुनें।" }
        val error = BackendUrlPolicy.validate(baseUrl, apiKey.isNotBlank())
        require(error == null) { error ?: "Backend URL अमान्य है।" }
        val url = URL(baseUrl.trimEnd('/') + path)
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 20000; readTimeout = 120000
            instanceFollowRedirects = false
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setRequestProperty("Accept", "application/json, application/pdf")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }
        try {
            DataOutputStream(connection.outputStream).use { out ->
                writeField(out, "language", "hin+eng")
                writeField(out, "dpi", "220")
                var total = 0L
                uris.forEach { uri ->
                    val bytes = resolver.openInputStream(uri)?.use { input ->
                        val buffer = ByteArray(16 * 1024); val output = ByteArrayOutputStream(); var countTotal = 0
                        while (true) {
                            val count = input.read(buffer); if (count < 0) break
                            countTotal += count; total += count
                            require(total <= DocumentLoader.MAX_FILES_BYTES) { "कुल अपलोड 100 MB से अधिक है।" }
                            output.write(buffer, 0, count)
                        }
                        output.toByteArray()
                    } ?: error("फ़ाइल नहीं पढ़ी जा सकी।")
                    val name = displayName(uri).replace("\"", "_").replace("\r", "_").replace("\n", "_")
                    val mime = resolver.getType(uri) ?: "application/octet-stream"
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"files\"; filename=\"$name\"\r\n")
                    out.writeBytes("Content-Type: $mime\r\n\r\n")
                    out.write(bytes); out.writeBytes("\r\n")
                }
                out.writeBytes("--$boundary--\r\n"); out.flush()
            }
            val code = connection.responseCode
            if (code !in 200..299) {
                val detail = readLimited(connection.errorStream, 8 * 1024)
                throw IllegalStateException("Backend त्रुटि (HTTP $code): $detail")
            }
            return connection.inputStream.use { input ->
                val output = ByteArrayOutputStream(); val buffer = ByteArray(16 * 1024); var total = 0L
                while (true) {
                    val count = input.read(buffer); if (count < 0) break
                    total += count; require(total <= 200L * 1024L * 1024L) { "Backend response बहुत बड़ी है।" }
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
        } finally { connection.disconnect() }
    }

    private fun writeField(out: DataOutputStream, name: String, value: String) {
        out.writeBytes("--$boundary\r\n")
        out.writeBytes("Content-Disposition: form-data; name=\"$name\"\r\n\r\n")
        out.write(value.toByteArray(Charsets.UTF_8)); out.writeBytes("\r\n")
    }

    private fun displayName(uri: Uri): String {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0) ?: "scan.png"
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "scan.png"
    }

    private fun readLimited(stream: java.io.InputStream?, limit: Int): String {
        if (stream == null) return ""
        return stream.use { input ->
            val buffer = ByteArray(limit + 1); val read = input.read(buffer)
            String(buffer, 0, read.coerceAtLeast(0).coerceAtMost(limit), Charsets.UTF_8)
        }
    }
}
