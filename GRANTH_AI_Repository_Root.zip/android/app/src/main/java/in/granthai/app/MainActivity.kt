package `in`.granthai.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {
    companion object {
        private const val PICK_FILES = 1001
        private const val SAVE_TXT = 1101
        private const val SAVE_DOCX = 1102
        private const val SAVE_EPUB = 1103
        private const val SAVE_SEARCHABLE_PDF = 1104
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("granth_ai_local", MODE_PRIVATE) }
    private val secureStore by lazy { SecureKeyStore() }
    private val pages = mutableListOf<BookPage>()
    private val sourceUris = mutableListOf<Uri>()
    private var pageIndex = 0
    private var updatingEditor = false

    private lateinit var statusView: TextView
    private lateinit var pageInfo: TextView
    private lateinit var sourceInfo: TextView
    private lateinit var editor: EditText
    private lateinit var titleInput: EditText
    private lateinit var previousButton: Button
    private lateinit var nextButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        restoreDraft()
        renderPage()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(244, 247, 251)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(28))
        }
        scroll.addView(root)

        val brand = TextView(this).apply {
            text = "GRANTH AI"
            textSize = 27f
            setTextColor(Color.rgb(22, 42, 68))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        root.addView(brand)
        root.addView(label("मुद्रित पुस्तक से संपादन योग्य डिजिटल पुस्तक", 14f, Color.DKGRAY))
        root.addView(spacer(14))

        root.addView(sectionTitle("1. पुस्तक चुनें"))
        root.addView(row(
            actionButton("फ़ोटो / PDF चुनें") { chooseFiles() },
            actionButton("स्थानीय OCR फिर चलाएँ") { runLocalOcr() }
        ))
        root.addView(label("सुझाव: कई पृष्ठों वाली PDF या एक से अधिक स्कैन फ़ाइलें एक साथ चुनें।", 12f, Color.DKGRAY))
        root.addView(spacer(12))

        root.addView(sectionTitle("2. पुस्तक संपादित करें"))
        titleInput = EditText(this).apply {
            hint = "पुस्तक का शीर्षक"
            setTextColor(Color.rgb(25, 35, 48))
            textSize = 16f
            setSingleLine(true)
            setText(prefs.getString("title", "मेरी डिजिटल पुस्तक"))
            background = roundedBackground(Color.WHITE, Color.rgb(210, 219, 230))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        root.addView(titleInput, matchWidth())
        titleInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { prefs.edit().putString("title", s?.toString().orEmpty()).apply() }
            override fun afterTextChanged(s: Editable?) {}
        })
        root.addView(spacer(10))
        pageInfo = label("कोई पृष्ठ नहीं", 13f, Color.rgb(35, 55, 80))
        root.addView(pageInfo)
        sourceInfo = label("स्रोत: —", 12f, Color.DKGRAY)
        root.addView(sourceInfo)
        root.addView(row(
            actionButton("◀ पिछला") { showPage(pageIndex - 1) }.also { previousButton = it },
            actionButton("अगला ▶") { showPage(pageIndex + 1) }.also { nextButton = it }
        ))
        editor = EditText(this).apply {
            hint = "OCR से निकला पाठ यहाँ दिखेगा। आप इसे सुधार सकते हैं…"
            textSize = 16f
            gravity = Gravity.TOP or Gravity.START
            minLines = 12
            setTextColor(Color.rgb(30, 38, 48))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = roundedBackground(Color.WHITE, Color.rgb(205, 216, 228))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        root.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(270)))
        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!updatingEditor && pageIndex in pages.indices) {
                    pages[pageIndex].text = s?.toString().orEmpty()
                    saveDraft()
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        root.addView(spacer(14))

        root.addView(sectionTitle("3. वैकल्पिक Backend"))
        root.addView(row(
            actionButton("Backend OCR + गुणवत्ता") { runBackendOcr() },
            actionButton("Searchable PDF") { chooseSearchablePdfDestination() }
        ))
        root.addView(actionButton("Backend URL / API Key सेटिंग्स") { showBackendSettings() }, matchWidth())
        root.addView(label("Backend OCR और Searchable PDF में चुनी गई मूल फ़ाइलें सर्वर पर अपलोड होंगी। स्थानीय OCR और संपादन फोन पर रहते हैं।", 12f, Color.DKGRAY))
        root.addView(spacer(14))

        root.addView(sectionTitle("4. निर्यात"))
        root.addView(row(
            actionButton("TXT निर्यात") { createOutput(SAVE_TXT) },
            actionButton("DOCX निर्यात") { createOutput(SAVE_DOCX) }
        ))
        root.addView(actionButton("EPUB 3 निर्यात") { createOutput(SAVE_EPUB) }, matchWidth())
        root.addView(spacer(12))

        statusView = label("तैयार — पुस्तक की फ़ाइल चुनें।", 13f, Color.rgb(25, 70, 52)).apply {
            setPadding(dp(12), dp(10), dp(12), dp(10)); background = roundedBackground(Color.rgb(229, 242, 235), Color.rgb(200, 224, 210))
        }
        root.addView(statusView, matchWidth())
        setContentView(scroll)
    }

    private fun chooseFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "image/jpeg", "image/png", "image/webp", "image/tiff", "image/*"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, PICK_FILES)
    }

    @Deprecated("Legacy activity result is used to keep this project dependency-light.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            PICK_FILES -> {
                val selected = mutableListOf<Uri>()
                data.clipData?.let { clip -> for (i in 0 until clip.itemCount) selected += clip.getItemAt(i).uri }
                data.data?.let { if (selected.isEmpty()) selected += it }
                if (selected.isNotEmpty()) {
                    selected.forEach { uri -> try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
                    sourceUris.clear(); sourceUris.addAll(selected)
                    runLocalOcr()
                }
            }
            SAVE_TXT -> writeExport(data.data, "txt")
            SAVE_DOCX -> writeExport(data.data, "docx")
            SAVE_EPUB -> writeExport(data.data, "epub")
            SAVE_SEARCHABLE_PDF -> writeExport(data.data, "searchable-pdf")
        }
    }

    private fun runLocalOcr() {
        if (sourceUris.isEmpty()) { showStatus("पहले फ़ोटो या PDF चुनें।", true); return }
        val inputs = sourceUris.toList()
        pages.clear(); pageIndex = 0; renderPage()
        showStatus("स्थानीय OCR चल रहा है… बड़ी PDF में कुछ समय लग सकता है।")
        worker.execute {
            try {
                val completed = mutableListOf<BookPage>()
                inputs.forEach { uri ->
                    val fileName = DocumentLoader.displayName(this, uri)
                    DocumentLoader.forEachPage(this, uri) { bitmap, _ ->
                        require(completed.size < DocumentLoader.MAX_PAGES) { "कुल पृष्ठ सीमा 200 है।" }
                        val text = OcrEngine.recognise(bitmap)
                        completed += BookPage(fileName, text, completed.size + 1)
                    }
                }
                runOnUiThread {
                    pages.clear(); pages.addAll(completed); pageIndex = 0
                    saveDraft(); renderPage()
                    showStatus("स्थानीय OCR पूरा: ${pages.size} पृष्ठ। पाठ की मूल स्कैन से जाँच करें।")
                }
            } catch (error: Exception) {
                runOnUiThread { showStatus("OCR त्रुटि: ${error.message ?: "फ़ाइल पढ़ी नहीं जा सकी।"}", true) }
            }
        }
    }

    private fun runBackendOcr() {
        if (sourceUris.isEmpty()) { showStatus("पहले फ़ोटो या PDF चुनें।", true); return }
        val client = backendClientOrError() ?: return
        val inputs = sourceUris.toList()
        showStatus("Backend OCR के लिए फ़ाइलें अपलोड हो रही हैं…")
        worker.execute {
            try {
                val result = client.runOcr(inputs)
                runOnUiThread {
                    pages.clear(); pages.addAll(result); pageIndex = 0
                    saveDraft(); renderPage()
                    showStatus("Backend OCR पूरा: ${pages.size} पृष्ठ। कम विश्वास वाले शब्दों को मूल स्कैन से जाँचें।")
                }
            } catch (error: Exception) { runOnUiThread { showStatus("Backend OCR विफल: ${error.message}", true) } }
        }
    }

    private fun chooseSearchablePdfDestination() {
        if (sourceUris.isEmpty()) { showStatus("पहले फ़ोटो या PDF चुनें।", true); return }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            putExtra(Intent.EXTRA_TITLE, "granth-searchable.pdf")
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, SAVE_SEARCHABLE_PDF)
    }

    private fun createOutput(type: Int) {
        if (pages.isEmpty()) { showStatus("निर्यात से पहले OCR करके पृष्ठ जोड़ें।", true); return }
        val (mime, fileName) = when (type) {
            SAVE_TXT -> "text/plain" to "granth-book.txt"
            SAVE_DOCX -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document" to "granth-book.docx"
            else -> "application/epub+zip" to "granth-book.epub"
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); this.type = mime; putExtra(Intent.EXTRA_TITLE, fileName)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, type)
    }

    private fun writeExport(uri: Uri?, kind: String) {
        if (uri == null) return
        if (kind == "searchable-pdf") {
            val client = backendClientOrError() ?: return
            val inputs = sourceUris.toList()
            showStatus("Searchable PDF सर्वर पर तैयार हो रही है…")
            worker.execute {
                try {
                    val bytes = client.searchablePdf(inputs)
                    contentResolver.openOutputStream(uri, "w")?.use { it.write(bytes) } ?: error("चुनी गई जगह पर फ़ाइल नहीं लिखी जा सकी।")
                    runOnUiThread { showStatus("Searchable PDF सेव हो गई। इसमें स्कैन चित्र और खोज योग्य OCR text layer है।") }
                } catch (error: Exception) { runOnUiThread { showStatus("PDF निर्यात विफल: ${error.message}", true) } }
            }
            return
        }
        val snapshot = pages.map { it.copy() }
        val title = titleInput.text.toString().ifBlank { "मेरी डिजिटल पुस्तक" }
        try {
            contentResolver.openOutputStream(uri, "w")?.use { output ->
                when (kind) {
                    "txt" -> output.write(LocalExporter.text(title, snapshot))
                    "docx" -> LocalExporter.docx(title, snapshot, output)
                    "epub" -> LocalExporter.epub(title, snapshot, output)
                }
            } ?: error("चुनी गई जगह पर फ़ाइल नहीं लिखी जा सकी।")
            showStatus("$kind निर्यात सफल। फ़ाइल को खोलकर जाँच लें।")
        } catch (error: Exception) { showStatus("निर्यात विफल: ${error.message}", true) }
    }

    private fun showBackendSettings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(4)) }
        val urlInput = EditText(this).apply {
            hint = "https://आपका-backend.example"
            setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("backend_url", ""))
        }
        val keyInput = EditText(this).apply {
            hint = "वैकल्पिक API Key"; setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(try { secureStore.decrypt(prefs.getString("backend_key_enc", "") ?: "") } catch (_: Exception) { "" })
        }
        box.addView(label("Backend URL", 13f, Color.DKGRAY)); box.addView(urlInput)
        box.addView(label("Bearer API Key (यदि आवश्यक हो)", 13f, Color.DKGRAY)); box.addView(keyInput)
        box.addView(label("Remote/LAN server के लिए HTTPS अनिवार्य है। API key को HTTP पर न भेजें।", 12f, Color.DKGRAY))
        val test = actionButton("कनेक्शन जाँचें") {
            val url = urlInput.text.toString(); val key = keyInput.text.toString()
            val error = BackendUrlPolicy.validate(url, key.isNotBlank())
            if (error != null) { Toast.makeText(this, error, Toast.LENGTH_LONG).show(); return@actionButton }
            val client = BackendClient(this, url, key)
            showStatus("Backend health जाँची जा रही है…")
            worker.execute {
                try { val result = client.checkHealth(); runOnUiThread { showStatus(result) } }
                catch (e: Exception) { runOnUiThread { showStatus("कनेक्शन विफल: ${e.message}", true) } }
            }
        }
        box.addView(test, matchWidth())
        val dialog = AlertDialog.Builder(this)
            .setTitle("Backend सेटिंग्स")
            .setView(box)
            .setNegativeButton("रद्द", null)
            .setPositiveButton("सहेजें", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val url = urlInput.text.toString().trim()
                val key = keyInput.text.toString()
                if (url.isNotBlank()) {
                    val error = BackendUrlPolicy.validate(url, key.isNotBlank())
                    if (error != null) { Toast.makeText(this, error, Toast.LENGTH_LONG).show(); return@setOnClickListener }
                }
                try {
                    prefs.edit().putString("backend_url", url).putString("backend_key_enc", secureStore.encrypt(key)).apply()
                    dialog.dismiss(); showStatus("Backend सेटिंग्स सुरक्षित रूप से सहेजी गईं।")
                } catch (e: Exception) { Toast.makeText(this, "API key सुरक्षित नहीं हो सकी: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
        dialog.show()
    }

    private fun backendClientOrError(): BackendClient? {
        val url = prefs.getString("backend_url", "")?.trim().orEmpty()
        if (url.isBlank()) { showStatus("पहले Backend URL सेट करें।", true); showBackendSettings(); return null }
        val key = try { secureStore.decrypt(prefs.getString("backend_key_enc", "") ?: "") }
        catch (_: Exception) { showStatus("सहेजी गई API key decrypt नहीं हुई। Backend सेटिंग्स में नई key डालें।", true); return null }
        val error = BackendUrlPolicy.validate(url, key.isNotBlank())
        if (error != null) { showStatus(error, true); return null }
        return BackendClient(this, url, key)
    }

    private fun showPage(index: Int) {
        if (index !in pages.indices) return
        pageIndex = index; renderPage()
    }

    private fun renderPage() {
        val hasPage = pageIndex in pages.indices
        updatingEditor = true
        if (hasPage) {
            val page = pages[pageIndex]
            pageInfo.text = "पृष्ठ ${pageIndex + 1} / ${pages.size}"
            val confidence = page.averageConfidence?.let { " | औसत विश्वास: ${"%.1f".format(java.util.Locale.US, it)}%" }.orEmpty()
            val layout = page.layout?.let { " | $it" }.orEmpty()
            val low = if (page.lowConfidenceCount > 0) " | कम-विश्वास शब्द: ${page.lowConfidenceCount}" else ""
            val warning = if (page.warnings.isNotEmpty()) " | ${page.warnings.joinToString(" ")}" else ""
            sourceInfo.text = "स्रोत: ${page.sourceName}$confidence$layout$low$warning"
            editor.setText(page.text)
        } else {
            pageInfo.text = "कोई पृष्ठ नहीं"
            sourceInfo.text = "स्रोत: —"
            editor.setText("")
        }
        editor.isEnabled = hasPage
        previousButton.isEnabled = hasPage && pageIndex > 0
        nextButton.isEnabled = hasPage && pageIndex < pages.size - 1
        updatingEditor = false
    }

    private fun restoreDraft() {
        titleInput.setText(prefs.getString("title", "मेरी डिजिटल पुस्तक"))
        val raw = prefs.getString("draft", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val confidence = if (obj.has("confidence") && !obj.isNull("confidence")) obj.optDouble("confidence") else null
                val warningsJson = obj.optJSONArray("warnings")
                val warnings = if (warningsJson == null) emptyList() else (0 until warningsJson.length()).map { warningsJson.optString(it) }
                pages += BookPage(
                    sourceName = obj.optString("source", "स्थानीय ड्राफ्ट"),
                    text = obj.optString("text", ""),
                    pageNumber = obj.optInt("page", i + 1),
                    averageConfidence = confidence,
                    lowConfidenceCount = obj.optInt("low_count", 0),
                    layout = obj.optString("layout").takeIf { it.isNotBlank() },
                    warnings = warnings
                )
            }
        } catch (_: Exception) { pages.clear() }
    }

    private fun saveDraft() {
        val array = JSONArray()
        pages.forEach { page ->
            val item = JSONObject().put("source", page.sourceName).put("text", page.text).put("page", page.pageNumber)
                .put("low_count", page.lowConfidenceCount)
            page.averageConfidence?.let { item.put("confidence", it) }
            page.layout?.let { item.put("layout", it) }
            item.put("warnings", JSONArray(page.warnings))
            array.put(item)
        }
        prefs.edit().putString("draft", array.toString()).apply()
    }

    private fun showStatus(message: String, error: Boolean = false) {
        statusView.text = message
        statusView.setTextColor(if (error) Color.rgb(145, 36, 36) else Color.rgb(25, 70, 52))
    }

    private fun label(textValue: String, size: Float, color: Int) = TextView(this).apply {
        text = textValue; textSize = size; setTextColor(color)
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.rgb(25, 49, 77)); setPadding(0, dp(4), 0, dp(8))
    }

    private fun actionButton(value: String, action: () -> Unit) = Button(this).apply {
        text = value; textSize = 12f; isAllCaps = false; setOnClickListener { action() }
        minHeight = dp(46); setPadding(dp(8), dp(4), dp(8), dp(4))
    }

    private fun row(left: View, right: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
    }

    private fun roundedBackground(fill: Int, stroke: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(12).toFloat()
    }

    private fun spacer(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onPause() { saveDraft(); super.onPause() }
    override fun onDestroy() { worker.shutdown(); super.onDestroy() }
}
