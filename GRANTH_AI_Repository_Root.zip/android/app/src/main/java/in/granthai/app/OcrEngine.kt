package `in`.granthai.app

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.TimeUnit
import kotlin.math.abs

object OcrEngine {
    private val devanagari by lazy {
        TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
    }
    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private data class LinePart(val top: Int, val left: Int, val height: Int, val text: String)

    fun recognise(bitmap: Bitmap): String {
        val image = InputImage.fromBitmap(bitmap, 0)
        val hindiResult = Tasks.await(devanagari.process(image), 90, TimeUnit.SECONDS)
        val latinResult = Tasks.await(latin.process(image), 90, TimeUnit.SECONDS)
        val parts = mutableListOf<LinePart>()
        fun collect(result: Text) {
            result.textBlocks.forEach { block ->
                block.lines.forEach { line ->
                    val box = line.boundingBox
                    parts += LinePart(box?.top ?: 0, box?.left ?: 0, box?.height() ?: 16, line.text)
                }
            }
        }
        collect(hindiResult); collect(latinResult)
        if (parts.isEmpty()) return ""

        // Merge Devanagari and Latin fragments that share the same visual baseline.
        val grouped = mutableListOf<MutableList<LinePart>>()
        parts.sortedBy { it.top }.forEach { part ->
            val target = grouped.lastOrNull()?.takeIf { group ->
                val mean = group.map { it.top + it.height / 2 }.average().toInt()
                abs((part.top + part.height / 2) - mean) <= maxOf(10, part.height, group.maxOf { it.height }) * 0.65
            }
            if (target == null) grouped += mutableListOf(part) else target += part
        }
        return grouped.joinToString("\n") { row -> row.sortedBy { it.left }.joinToString(" ") { it.text.trim() } }
    }

    fun close() {
        try { devanagari.close() } catch (_: Exception) { }
        try { latin.close() } catch (_: Exception) { }
    }
}
