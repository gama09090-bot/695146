package `in`.granthai.app

import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object LocalExporter {
    fun text(title: String, pages: List<BookPage>): ByteArray = buildString {
        append(title).append("\n\n")
        pages.forEachIndexed { index, page ->
            if (index > 0) append("\n\n")
            append("पृष्ठ ").append(page.pageNumber).append("\n")
            append(page.text)
        }
    }.toByteArray(Charsets.UTF_8)

    fun docx(title: String, pages: List<BookPage>, output: OutputStream) {
        val body = StringBuilder()
        fun paragraph(value: String, style: String = "") {
            body.append("<w:p>")
            if (style.isNotEmpty()) body.append("<w:pPr><w:pStyle w:val=\"").append(style).append("\"/></w:pPr>")
            body.append("<w:r><w:t xml:space=\"preserve\">").append(xml(value)).append("</w:t></w:r></w:p>")
        }
        paragraph(title, "Title")
        pages.forEachIndexed { index, page ->
            if (index > 0) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            paragraph("पृष्ठ ${page.pageNumber}", "Heading1")
            page.text.split('\n').forEach { paragraph(it) }
        }
        val documentXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$body<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1000" w:right="1000" w:bottom="1000" w:left="1000"/></w:sectPr></w:body></w:document>""".trimIndent()
        val contentTypes = """<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>"""
        val rels = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>"""
        val documentRels = """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
        val styles = """<?xml version="1.0" encoding="UTF-8"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/></w:style></w:styles>"""
        ZipOutputStream(output).use { zip ->
            zip.putText("[Content_Types].xml", contentTypes)
            zip.putText("_rels/.rels", rels)
            zip.putText("word/document.xml", documentXml)
            zip.putText("word/_rels/document.xml.rels", documentRels)
            zip.putText("word/styles.xml", styles)
        }
    }

    fun epub(title: String, pages: List<BookPage>, output: OutputStream) {
        val id = UUID.randomUUID().toString()
        val formatter = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val modified = formatter.format(Date())
        val pageNames = pages.indices.map { "page%04d.xhtml".format(it + 1) }
        val manifest = pageNames.mapIndexed { i, name -> "<item id=\"p${i + 1}\" href=\"$name\" media-type=\"application/xhtml+xml\"/>" }.joinToString("")
        val spine = pages.indices.joinToString("") { "<itemref idref=\"p${it + 1}\"/>" }
        val packageDoc = """<?xml version="1.0" encoding="UTF-8"?>
            <package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid" xml:lang="hi"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="bookid">urn:uuid:$id</dc:identifier><dc:title>${xml(title)}</dc:title><dc:language>hi</dc:language><meta property="dcterms:modified">$modified</meta></metadata><manifest>$manifest</manifest><spine>$spine</spine></package>""".trimIndent()
        val container = """<?xml version="1.0" encoding="UTF-8"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>"""
        ZipOutputStream(output).use { zip ->
            val mime = ZipEntry("mimetype").apply { method = ZipEntry.STORED; size = "application/epub+zip".toByteArray().size.toLong(); compressedSize = size; crc = java.util.zip.CRC32().apply { update("application/epub+zip".toByteArray()) }.value }
            zip.putNextEntry(mime); zip.write("application/epub+zip".toByteArray()); zip.closeEntry()
            zip.putText("META-INF/container.xml", container)
            zip.putText("OEBPS/content.opf", packageDoc)
            pages.forEachIndexed { index, page ->
                val paragraphs = page.text.split('\n').joinToString("") { "<p>${xml(it)}</p>" }
                val xhtml = """<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml" lang="hi"><head><title>पृष्ठ ${page.pageNumber}</title><meta charset="utf-8"/></head><body><h1>पृष्ठ ${page.pageNumber}</h1>$paragraphs</body></html>"""
                zip.putText("OEBPS/${pageNames[index]}", xhtml)
            }
        }
    }

    private fun xml(value: String): String = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
    private fun ZipOutputStream.putText(path: String, value: String) {
        putNextEntry(ZipEntry(path)); write(value.toByteArray(Charsets.UTF_8)); closeEntry()
    }
}
