package `in`.granthai.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class BackendUrlPolicyTest {
    @Test fun httpsRemoteIsAllowed() {
        assertNull(BackendUrlPolicy.validate("https://ocr.example.org", true, 35))
    }
    @Test fun loopbackHttpWithoutKeyIsAllowed() {
        assertNull(BackendUrlPolicy.validate("http://127.0.0.1:8000", false, 35))
        assertNull(BackendUrlPolicy.validate("http://10.0.2.2:8000", false, 35))
    }
    @Test fun emulatorAliasCannotReceiveBearerKeyOverHttp() {
        assertEquals("API key के साथ HTTP केवल localhost या 127.0.0.1 पर मान्य है।",
            BackendUrlPolicy.validate("http://10.0.2.2:8000", true, 35))
    }
    @Test fun remoteLanHttpIsBlocked() {
        assertEquals("LAN/दूरस्थ Backend के लिए HTTPS आवश्यक है।",
            BackendUrlPolicy.validate("http://192.168.1.9:8000", false, 35))
    }
    @Test fun api23RequiresHttps() {
        assertEquals("Android 6/API 23 पर HTTP बंद है; HTTPS उपयोग करें।",
            BackendUrlPolicy.validate("http://localhost:8000", false, 23))
    }
    @Test fun nonHttpSchemesAndUriCredentialsAreRejected() {
        assertEquals("केवल HTTPS या अनुमत स्थानीय HTTP समर्थित है।", BackendUrlPolicy.validate("ftp://ocr.example.org", false, 35))
        assertEquals("URL में user-info, query या fragment न रखें।", BackendUrlPolicy.validate("https://user:pass@example.org", false, 35))
    }
}
